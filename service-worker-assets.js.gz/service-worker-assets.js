self.assetsManifest = {
  "version": "57vbBL81",
  "assets": [
    {
      "hash": "sha256-UVy3L6kXaa89JN6tg+EbiLCuVLpkmxOoG6sAi7Bb9uc=",
      "url": "BlazorWasmPreRendering.Build.lfyg69o9wu.lib.module.js"
    },
    {
      "hash": "sha256-U8gezSK6nXfxXIBXZlEhJKupcHbUrpB1ieSNV3tcpb0=",
      "url": "_content/SampleSite.Components/nupkg-icon.png"
    },
    {
      "hash": "sha256-j1ghtzgc+YIGeK0mGYAKzPnPECcusuk0xzDUVL8yUms=",
      "url": "_content/SampleSite.Components/styles.css"
    },
    {
      "hash": "sha256-e2JX9RRuddPtKelfro7f1XWlcxUqYbi1GFm0LPsNJJo=",
      "url": "_content/Toolbelt.Blazor.Gamepad/script.min.js"
    },
    {
      "hash": "sha256-zg6rExHdQD6G82sQ94ltkJNJHDKhaWngTwtWQE+59zo=",
      "url": "_content/Toolbelt.Blazor.HeadElement.Services/script.min.js"
    },
    {
      "hash": "sha256-1SCwrIU2yalMU8piERXy1Js+a9Ws+CyktgM0VfOO0M0=",
      "url": "_content/Toolbelt.Blazor.HeadElement.Services/script.module.min.js"
    },
    {
      "hash": "sha256-a7+376JQO3Guvp29tXoXZIRGrBpYmp5Q15aKx5ZRMxk=",
      "url": "_framework/Microsoft.AspNetCore.Components.1d4ao1x1kb.wasm"
    },
    {
      "hash": "sha256-652qH8/F+HEwQzcC3k1vp7I8NQ/xquZ3aElSCCP4NgU=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.ze1rqtzt8x.wasm"
    },
    {
      "hash": "sha256-kOcwPJ2Fvuwie/puDKEFZYrI6So3WZ3HMjI2rBMmjF8=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.c517e2dkv4.wasm"
    },
    {
      "hash": "sha256-t6RTssXXLKtSJOUT6iI/BYV3YrPbautTCsqhz549lCU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.rvgls4fdhk.wasm"
    },
    {
      "hash": "sha256-eo/oa3JT4Cc/LE0otD/LWr4fQN9Vz7QtpfNt8oeccXM=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.q0m0kr40cg.wasm"
    },
    {
      "hash": "sha256-I4+EaVahm205fWtCCjHNu0JQkCoqkwXkA83p797yGAM=",
      "url": "_framework/Microsoft.Extensions.Configuration.byt2r8jpbf.wasm"
    },
    {
      "hash": "sha256-acCED8dRnvLNnWqy3QvjvLCIeDKOBEuD3A120wuHhr4=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.7kgrfhq7r7.wasm"
    },
    {
      "hash": "sha256-mXNEKmwvWL3Omzzq2anNIWn5Mny05n1VkoU8+oVr8XE=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.zlpjsevw0s.wasm"
    },
    {
      "hash": "sha256-pFhzrjGnfc2UWVFA/5/M8MWDv7r0Z1wNi2papkOBgjs=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.kyk56yupp5.wasm"
    },
    {
      "hash": "sha256-lveY4zTZw8AEbESkgoYqtN4fiLFXAEfBdoYLdzmpLfE=",
      "url": "_framework/Microsoft.Extensions.Logging.q74thzykfo.wasm"
    },
    {
      "hash": "sha256-rzbf8+wupVlqTJB/lypNGaHQyBhotVApaPQEZ4keJKU=",
      "url": "_framework/Microsoft.Extensions.Options.z3amy2nl13.wasm"
    },
    {
      "hash": "sha256-WDvqFiKBP98gYWu4I/BuQQUjAR9Ap+OUIcUjx6NFGxI=",
      "url": "_framework/Microsoft.Extensions.Primitives.84gjz0mo6d.wasm"
    },
    {
      "hash": "sha256-Ig2bIxqVnjiSChMKy1KkF8kbDv/d4renKPcfokyZDus=",
      "url": "_framework/Microsoft.JSInterop.6i5oxour6z.wasm"
    },
    {
      "hash": "sha256-zIGd0h8/AoN3niSEUSSn1zX71vJ4hqGJZ3UwI1g+UD0=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.kivdlry06d.wasm"
    },
    {
      "hash": "sha256-jeEw2xsMZGMy4X/7knZvzk1QkBIAttQpoSCNkIdPZLo=",
      "url": "_framework/SampleSite.Client.xvd1h50wzb.wasm"
    },
    {
      "hash": "sha256-VGl/VPh7Df8srVxnEKtCuo6ROlkS0cYZX+5WWRX+nbA=",
      "url": "_framework/SampleSite.Components.01vl1ybf5v.wasm"
    },
    {
      "hash": "sha256-tMixsUF4GSgbd7+FHB6PICB4tUpDj29znyKxTr6gLUA=",
      "url": "_framework/System.0x1wb7tfot.wasm"
    },
    {
      "hash": "sha256-17OdZiWxlN2U93TJJVsN/+gZ1gJ2bkvWc8lh6tAQLOs=",
      "url": "_framework/System.Collections.Concurrent.lhnl6vkgq1.wasm"
    },
    {
      "hash": "sha256-pLBocza4/T8PaMJOVabXpTT6du3ORT9Lp6k9t/KF0Ow=",
      "url": "_framework/System.Collections.Immutable.057ik266m0.wasm"
    },
    {
      "hash": "sha256-QGalCaLygYwRSRgmVmcJPbqsoS7UXKtoQ4t6/u+hCzw=",
      "url": "_framework/System.Collections.g8t1g75xqt.wasm"
    },
    {
      "hash": "sha256-8snw6KncFJIItKuDDmEfDGwz9i8Vo/pOVqYOfiUul9U=",
      "url": "_framework/System.ComponentModel.Primitives.207qksmd76.wasm"
    },
    {
      "hash": "sha256-Vw8Mn9ESdBPfeJGBhfWrzbo45kAUgCQjUwwHzmdINMk=",
      "url": "_framework/System.ComponentModel.TypeConverter.12a7qiadlg.wasm"
    },
    {
      "hash": "sha256-CR76GIDDw1MfCthwQyrZZq4JBsRxEB1vPmliVD9HL4U=",
      "url": "_framework/System.ComponentModel.xmxjt0ntly.wasm"
    },
    {
      "hash": "sha256-MRkAg0waLxUv8VyA2iEry/f7KfDr1k17HRPY89J+xhY=",
      "url": "_framework/System.Console.tpx6p811kt.wasm"
    },
    {
      "hash": "sha256-Cgkv0P5nJWOjy/4Dh7/xIh6jdl4G/PIytybV6ZgWi8Y=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.mkxci42bp7.wasm"
    },
    {
      "hash": "sha256-FWFhFxEZRtzlRy0d1OlgWHCxpJOCVc6uUn3yqvvXpYc=",
      "url": "_framework/System.IO.Pipelines.r4k8j9p1r8.wasm"
    },
    {
      "hash": "sha256-t8HaWSMinMPn4ZW8q6ugF3E11lItyBUaquj4fgsUr40=",
      "url": "_framework/System.Linq.hifva91zxj.wasm"
    },
    {
      "hash": "sha256-zrZeb5y8vGZTZhZUeaXHPjKIQQ837D7QR9cUJ4jq1uk=",
      "url": "_framework/System.Memory.eomsht1o95.wasm"
    },
    {
      "hash": "sha256-AaKdrHtdbMcMhQBdyX5A1DUsDJMTZkQTBRK/4YxiE9k=",
      "url": "_framework/System.Net.Http.1sx819i7r0.wasm"
    },
    {
      "hash": "sha256-QBoDIilFzHFlrQs/asjU2HbUx25/DlgvLOZfhQdB2NM=",
      "url": "_framework/System.Net.Primitives.sdtazd96f5.wasm"
    },
    {
      "hash": "sha256-m92xirOrIs/2P95AxvOv8kk18+FvTC9R9cEmxroWT3Y=",
      "url": "_framework/System.ObjectModel.93jvsplz1k.wasm"
    },
    {
      "hash": "sha256-UHsLgKvSFoBbgD+ez/cMVjoj+tDgvpBtoNrHfk+dSLs=",
      "url": "_framework/System.Private.CoreLib.ggoibtbcvw.wasm"
    },
    {
      "hash": "sha256-cOaYWscjq1jbSEInrNitMFTcVlDdG5iHmEKvGcwvzUc=",
      "url": "_framework/System.Private.Uri.sdi2ggcl1w.wasm"
    },
    {
      "hash": "sha256-71noB9qQb0oV/opHB90nfT9jvrgHEVbGsUM7mafL2i0=",
      "url": "_framework/System.Runtime.7qwp80q5e7.wasm"
    },
    {
      "hash": "sha256-STusHuW091sRW9n4q+lRIbpwkpf8iu25N7pMmzVUR1E=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.lpnpfmz986.wasm"
    },
    {
      "hash": "sha256-5STuuzqiWrDJm62Lw4UYwqJ73iHHx4OxypqBOqHCKqg=",
      "url": "_framework/System.Security.Cryptography.vv6xqw2hzq.wasm"
    },
    {
      "hash": "sha256-lK5oUPUa4ACk8zvqyxo7FKI7zV1E+gY65/48pm+Vwqs=",
      "url": "_framework/System.Text.Encodings.Web.0n7bqbbpil.wasm"
    },
    {
      "hash": "sha256-79IYeFQIKZP7SRWZk5p87DJkASLaOwkJaDnRdcbmZ2I=",
      "url": "_framework/System.Text.Json.5r01j4j7rm.wasm"
    },
    {
      "hash": "sha256-RKsWZUssDB/RXTQKl8L9d2RkU07BE1vcJyMUa4kULZ4=",
      "url": "_framework/System.Text.RegularExpressions.0vmwpkdzue.wasm"
    },
    {
      "hash": "sha256-J20rcbV7c4MgMFBrGgu0HlMTOqkSSdBz1KKAKq5GJgk=",
      "url": "_framework/System.Threading.7cncs8nli6.wasm"
    },
    {
      "hash": "sha256-NckJuDMYp/IDz5wqqL1NgTFsrcs4LIV+e4y2lWrrY+s=",
      "url": "_framework/Toolbelt.Blazor.Gamepad.d22zc6nw3i.wasm"
    },
    {
      "hash": "sha256-Y75VwEf7HtcK38P94hintQ/mS9jYJIMHjHBeLlbbuMI=",
      "url": "_framework/Toolbelt.Blazor.HeadElement.3owkc4sscm.wasm"
    },
    {
      "hash": "sha256-u501aGqqctPbubaom/I8a06VWX49+BPMkFdMD9DZ6Ns=",
      "url": "_framework/Toolbelt.Blazor.HeadElement.Abstractions.x5jlech633.wasm"
    },
    {
      "hash": "sha256-lUUkjiF9VItGEXZ1LJzjXzsABjxlCf4xn7aj66M3xQQ=",
      "url": "_framework/Toolbelt.Blazor.HeadElement.Services.d2s2vfnjr9.wasm"
    },
    {
      "hash": "sha256-1xlHuu1iNOJiMMz2BCq95uekwHf6pdpTcgVNKVBboPs=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-CragnVSgiwOK33PSTtGLxfqc0C7CpUyVevrcX0E1s3g=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-rDx4Ofp2zoLCuXRtnhoG3xIylhJ7fWl5Nr3jRZsuy4s=",
      "url": "_framework/dotnet.native.ks1hkr8ti5.wasm"
    },
    {
      "hash": "sha256-4wYLcb9md/4o50E14LsWpwumoYz2Zh6zU7Bu5wAXtLE=",
      "url": "_framework/dotnet.native.vpovwuqu2r.js"
    },
    {
      "hash": "sha256-/ndm/PF1BeBT5mXzYAES79wNK5sIZIQKAGcUqPL9ZP8=",
      "url": "_framework/dotnet.runtime.2zl32tp6ah.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-fHZ0dpuJmzRLgV87xXWUYDqM4mHcvkaaNnlHkwro7k8=",
      "url": "_framework/netstandard.o9qqrdaqm1.wasm"
    },
    {
      "hash": "sha256-sAkBwbsE4LivvbSRtn9EoDoHLx4yU+AIPQRAm6Cy8GI=",
      "url": "css/blazor-ui.css"
    },
    {
      "hash": "sha256-lqehqsKUaAnnNozj4bnXdM6UlKdzXsxJnVsMN+SjhAY=",
      "url": "favicon.ico"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-MnCu7oCN5ajA3JuEYmm6BpBfRup8jtmm+sijbVMXPGs=",
      "url": "index.html"
    },
    {
      "hash": "sha256-5CKAVpAj3oPZ1nfE9KeH9ucG5VQ/wW/w/KLCPAGmbjY=",
      "url": "manifest.webmanifest"
    }
  ]
};
